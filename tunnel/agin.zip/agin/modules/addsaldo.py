from agin import *

@bot.on(events.CallbackQuery(data=b'addsaldo'))
async def addsaldo(event):
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		z = db.execute("SELECT email FROM user").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit("**Choose User**",
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			email = await conv
			email = email.data.decode("ascii")
		saldo = db.execute("SELECT saldo FROM user WHERE email = (?)",(email,)).fetchone()[0]
		member = db.execute("SELECT member FROM user WHERE email = (?)",(email,)).fetchone()[0]
		print(saldo); print(member)
		xs = await bot.get_entity(int(member))
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Informasi Reseller ⟩**
**━━━━━━━━━━━━━━━━**
**» Nama:** `{xs.first_name}`
**» Username:** `{xs.username}`
**» Member ID:** `{member}`
**» Saldo Tersisa:** `{saldo}`
**» Email:** `{email}`
**━━━━━━━━━━━━━━━━**
**Lanjutkan Mengisi Saldo?**
**━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline("Ya","y"),Button.inline("Tidak","n")],
[Button.inline("«🔙 Back To Menu «","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") == "y":
			await event.edit("**Masukkan Saldo Yang Akan Di Tambahkan: **")
			async with bot.conversation(event.chat_id) as sal:
				sal = sal.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				sal = await sal
				sal = sal.message.message
				print(sal)
			db.execute("UPDATE user SET saldo = (?) WHERE member = (?)",
			(int(saldo)+int(sal),member,))
			db.commit()
			msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Sukses Menambahkan Saldo ⟩**
**━━━━━━━━━━━━━━━━**
**» Nama:** `{xs.first_name}`
**» Username:** `{xs.username}`
**» Member ID:** `{member}`
**» Total Saldo:** `{int(saldo)+int(sal)}`
**» Email:** `{email}`
**━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg)
		else:
			await event.edit("**Dibatalkan.**")