from agin import *

@bot.on(events.CallbackQuery(data=b'info'))
async def info(event):
    sender = await event.get_sender()
    db = get_db()
    x = db.execute("SELECT user_id FROM admin").fetchall()
    admin_user_ids = [v[0] for v in x]
    member = members()
    
    if sender.id in admin_user_ids:
        msg = f"""
**Account Status:**
Status: Buyer
ID account   : `{val["member"]}`
Email Account: `{val["email"]}`
Saldo Account: `{val["saldo"]}`
Total Member/Buyer: `{member}`
"""
        button = [
            [Button.inline(" ➕Tambah Saldo➕ ", "topup")],
            #[Button.inline(" CEK ACCOUNT", "cek")],
            [Button.inline(" 🔙 Back To Menu ", "menu")] 
        ]
        
        z = await event.edit(msg, buttons=button)
        if not z:
            await event.respond(msg, buttons=button)
    else:
        val = valid(sender.id)
        if val == "false":
            try:
                await event.answer("**❌**")
            except:
                await event.respond("**❌**")
        else:
            msg = f"""
**Account Status:**
Status: Buyer
ID account   : `{val["member"]}`
Email Account: `{val["email"]}`
Saldo Account: `{val["saldo"]}`
Total Member/Buyer: `{member}`
"""
            button = [
                [Button.inline(" ➕Tambah Saldo➕ ", "topup")],
                #[Button.inline(" CEK ACCOUNT", "cek")],
                [Button.inline(" 🔙 Back To Menu ", "menu")] 
            ]
            
            x = await event.edit(msg, buttons=button)
            if not x:
                await event.respond(msg, buttons=button)

